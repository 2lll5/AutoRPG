import "./globals.css";

export const metadata = {
  title: "星蝕王冠H|�每小時生長的劍與魔法 RPG",
  description: "踏入艾瑟蘭，在劍道、祕法與靈契之間選擇。每條道路都會長出不同冒險，直到星蝕終夜迎來專屬結局。",
  openGraph: {
    title: "星蝕王冠H|�AutoRPG",
    description: "一款會隨時間生長、保存每次誓約的劍與魔法分支 RPG。",
    type: "website",
  },
};

export const viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#110d0b",
};

export default function RootLayout({ children }) {
  return (
    <html lang="zh-Hant">
      <body>{children}</body>
    </html>
  );
}
